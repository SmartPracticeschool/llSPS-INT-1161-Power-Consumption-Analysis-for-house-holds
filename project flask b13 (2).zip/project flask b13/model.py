# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pickle

data1 = pd.read_csv('2.csv')
data1.replace('?', np.nan, inplace=True)
data1['Global_active_power'].fillna(data1['Global_active_power'].median(),inplace=True)
data1['Global_reactive_power'].fillna(data1['Global_reactive_power'].median(),inplace=True)
data1['Voltage'].fillna(data1['Voltage'].median(),inplace=True)
data1['Global_intensity'].fillna(data1['Global_intensity'].median(),inplace=True)
data1['Sub_metering_1'].fillna(data1['Sub_metering_1'].median(),inplace=True)
data1['Sub_metering_2'].fillna(data1['Sub_metering_2'].median(),inplace=True)
data1['Sub_metering_3'].fillna(data1['Sub_metering_3'].median(),inplace=True)
data1 = data1.drop(columns=['Time','Date'])
values = data1.values.astype('float32')
data1['sub_metering_4'  ] = (values[:,0] * 1000 / 60) - (values[:,4] + values[:,5] + values[:,6])



X = data1.iloc[:, 0:7]

y = data1.iloc[:, -1]

#Splitting Training and Test Set
#Since we have a very small dataset, we will train our model with all availabe data.

from sklearn.linear_model import LinearRegression
regressor = LinearRegression()

#Fitting model with trainig data
regressor.fit(X, y)

# Saving model to disk
pickle.dump(regressor, open('model.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))
print(model.predict([[2.58,0.136,241.97,10.6,0,0,0]]))