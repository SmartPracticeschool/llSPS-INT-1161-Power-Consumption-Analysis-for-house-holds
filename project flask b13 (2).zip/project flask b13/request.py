import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'Global_active_power':1,'Global_reactive_power':1,'Voltage':5,'Global_intensity':5,'Sub_metering_1':0,'Sub_metering_2':6,'Sub_metering_3':0
})

print(r.json())
